#pragma once

#if defined(__APPLE__)

#define GE_PLATFORM_APPLE 1

#include <TargetConditionals.h>

#if TARGET_OS_MAC

#define GE_PLATFORM_MAC 1

#elif TARGET_OS_IOS

#define GE_PLATFORM_IOS 1

#else

#error Unsupported target Apple platform.

#endif

#elif defined(ANDROID) || defined(__ANDROID__)

#define GE_PLATFORM_ANDROID

#elif defined(linux) || defined(__linux) || defined(__linux__)

#define GE_PLATFORM_LINUX 1

#elif defined(_WIN32)

#define GE_PLATFORM_WINDOWS 1

#else

#error Unsupported target platform.

#endif

#if GE_PLATFORM_LINUX || GE_PLATFORM_ANDROID || GE_PLATFORM_APPLE

#define GE_PLATFORM_UNIX 1

#else

#define GE_PLATFORM_WINAPI 1

#endif

#if defined(__x86_64__) || defined(_M_X64)

#define GE_PLATFORM_ARCH_X64 1

#elif defined(__i386__) || defined(_M_IX86)

#define GE_PLATFORM_ARCH_X86 1

#elif defined(__arm__) || defined(_M_ARM)

#define GE_PLATFORM_ARCH_ARM32 1

#elif defined(__aarch64__) || defined(_M_ARM64)

#define GE_PLATFORM_ARCH_ARM64 1

#else

#error Unsupported CPU type.

#endif

#if GE_PLATFORM_LINUX || GE_PLATFORM_WINDOWS || GE_PLATFORM_MAC

#define GE_PLATFORM_DESKTOP 1

#elif GE_PLATFORM_ANDROID || GE_PLATFORM_IOS

#define GE_PLATFORM_MOBILE 1

#endif

#if GE_PLATFORM_ARCH_X64 || GE_PLATFORM_ARCH_ARM64

#define GE_PLATFORM_64BITS 1

#else

#define GE_PLATFORM_32BITS 1

#endif
