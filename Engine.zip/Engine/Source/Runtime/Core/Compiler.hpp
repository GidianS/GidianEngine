#pragma once

#if defined(__GNUC__)

#define GE_COMPILER_GNU 1

#elif defined(__clang__)

#define GE_COMPILER_CLANG 1

#elif defined(_MSC_VER)

#define GE_COMPILER_MSVC 1

#else

#error Unsupported compiler was use.

#endif

#define INLINE inline

#if GE_COMPILER_GNU || GE_COMPILER_CLANG

#define NO_INLINE __attribute__((noinline))

#define FORCE_INLINE inline __attribute__((always_inline))

#define GE_DLL_EXPORT __attribute__((visibility("default")))

#define GE_DLL_IMPORT __attribute__((visibility("default")))

#else

#define NO_INLINE __declspec(noinline)

#define FORCE_INLINE __forceinline

#define GE_DLL_EXPORT __declspec(dllexport)

#define GE_DLL_IMPORT __declspec(dllimport)

#endif

#if GE_BUILD_SHARED_LIB

#if GE_EXPORTS

#define GE_API GE_DLL_EXPORT

#else

#define GE_API GE_DLL_IMPORT

#endif

#else

#define GE_API

#endif
