#pragma once

#include <Core/Compiler.hpp>
#include <memory>

class GE_API Vector2
{
public:
    std::shared_ptr<Vector2> next; 

    float x;
    float y;

public:
    Vector2();
    Vector2(float v);
    Vector2(float x, float y);
    Vector2(const Vector2 & v1, const Vector2 & v2);
    ~Vector2();

    static const Vector2 zero;
    static const Vector2 one;
    static const Vector2 up;
    static const Vector2 right;
    static const Vector2 down;
    static const Vector2 left;
    
    FORCE_INLINE Vector2 operator+(const Vector2 & other) const
    {
        return Vector2(x + other.x, y + other.y);
    }

    FORCE_INLINE Vector2 & operator++()
    {
        ++x, ++y;

        return *this;
    }

    FORCE_INLINE Vector2 operator++(int)
    {
        Vector2 temp(*this);

        x++, y++;

        return temp;
    }

    FORCE_INLINE Vector2 & operator+=(const Vector2 & other)
    {
        x += other.x, y += other.y;

        return *this;
    }

    FORCE_INLINE Vector2 operator-(const Vector2 & other) const
    {
        return Vector2(x - other.x, y - other.y);
    }

    FORCE_INLINE Vector2 operator-() const
    {
        return Vector2(-x, -y);
    }

    FORCE_INLINE Vector2 & operator--()
    {
        --x, --y;

        return *this;
    }

    FORCE_INLINE Vector2 operator--(int)
    {
        Vector2 temp = *this;
        
        x--, y--;

        return temp;
    }

    FORCE_INLINE Vector2 & operator-=(const Vector2 & other)
    {
        x -= other.x, y -= other.y;

        return *this;
    }

    FORCE_INLINE Vector2 operator*(const Vector2 & other) const
    {
        return Vector2(x * other.x, y * other.y);
    }

    FORCE_INLINE Vector2 & operator*=(const Vector2 & other)
    {
        x *= other.x, y *= other.y;

        return *this;
    }

    FORCE_INLINE Vector2 operator/(const Vector2 & other) const
    {
        return Vector2(x / other.x, y / other.y);
    }

    FORCE_INLINE Vector2 & operator/=(const Vector2 & other)
    {
        x /= other.x, y /= other.y;

        return *this;
    }

    FORCE_INLINE bool operator==(const Vector2 & other) const
    {
        return (x == other.x) && (y == other.y);
    }

    FORCE_INLINE bool operator!=(const Vector2 & other) const
    {
        return (x != other.x) || (y != other.y);
    }

    FORCE_INLINE bool operator>(const Vector2 & other) const
    {
        return (x + y) > (other.x + other.y);
    }

    FORCE_INLINE bool operator>=(const Vector2 & other) const
    {
        return (x + y) >= (other.x + other.y);
    }

    FORCE_INLINE bool operator<(const Vector2 & other) const
    {
        return (x + y) < (other.x + other.y);
    }

    FORCE_INLINE bool operator<=(const Vector2 & other) const
    {
        return (x + y) <= (other.x + other.y);
    }
};
