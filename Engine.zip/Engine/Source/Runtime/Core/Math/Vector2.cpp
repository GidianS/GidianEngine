#include "Vector2.hpp"

Vector2::Vector2() : x(0), y(0) {}

Vector2::Vector2(float v) : x(v), y(v) {}

Vector2::Vector2(float x, float y) : x(x), y(y) {}

Vector2::Vector2(const Vector2 & v1, const Vector2 & v2) : x(v1.x), y(v2.y) {}

Vector2::~Vector2() {}

const Vector2 Vector2::zero = Vector2(0.0);

const Vector2 Vector2::one = Vector2(1.0);

const Vector2 Vector2::up = Vector2(0, 1);

const Vector2 Vector2::right = Vector2(1, 0);

const Vector2 Vector2::down = Vector2(0, -1);

const Vector2 Vector2::left = Vector2(-1, 0);

