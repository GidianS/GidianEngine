#include <iostream>
#include <memory>
#include <Core/Math/Vector2.hpp>

int main(int argc, char const *argv[])
{
    std::shared_ptr<Vector2> v1 = std::make_shared<Vector2>();
    std::shared_ptr<Vector2> v2 = std::make_shared<Vector2>();

    v1->x++;

    v1->next = v2;
    v2->next = v1;

    std::cout << "v1.x value : " << v1->x << std::endl;
    std::cout << "v1.y value : " << v1->y << std::endl;    
    std::cout << "v2.x value : " << v2->x << std::endl;
    std::cout << "v2.y value : " << v2->y << std::endl;

    return 0;
}
